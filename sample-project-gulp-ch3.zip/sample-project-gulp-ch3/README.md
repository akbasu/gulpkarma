# sample-project-gulp
The sample project we will use throughout the Gulp chapters
